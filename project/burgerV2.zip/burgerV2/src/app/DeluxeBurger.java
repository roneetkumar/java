package app;

/**
 * DeluxeBurger
 */
public class DeluxeBurger extends Burger {

    public DeluxeBurger() {
        super("Deluxe Burger", 14.54, "White", "Sousage", 2);
    }
}
