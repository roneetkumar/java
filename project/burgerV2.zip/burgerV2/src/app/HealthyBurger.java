package app;

/**
 * HealthyBurger
 */
public class HealthyBurger extends BasicBurger {

    public HealthyBurger() {
        super("Healthy Burger", 5.67, "Brown Rye", "Bacon", 6);
    }
}
