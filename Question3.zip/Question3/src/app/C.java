package app;

/**
 * C
 */
public class C extends A {
    public void f(long q) {
        System.out.println("C.f(long=" + q + ")");
    }
}
