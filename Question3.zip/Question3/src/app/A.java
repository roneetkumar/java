package app;

/**
 * A
 */
public class A {

    public void f(double x) {
        System.out.println("A.f(double=" + x + ")");
    }

}
