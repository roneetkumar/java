package app;

/**
 * D
 */
public class D extends C {
    public void f(int n) {
        System.out.println("C.f(long=" + n + ")");
    }
}
