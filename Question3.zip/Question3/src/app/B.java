package app;

/**
 * B
 */
public class B extends A {

}
