package app;

/**
 * F
 */
public class F extends C {
    public void f(float x) {
        System.out.println("F.f(float=" + x + ")");
    }

    public void f(int n) {
        System.out.println("F.f(float=" + n + ")");
    }
}
